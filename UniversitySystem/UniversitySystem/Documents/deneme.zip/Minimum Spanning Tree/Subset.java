

public class Subset {
    int parent;
    int rank;
}
