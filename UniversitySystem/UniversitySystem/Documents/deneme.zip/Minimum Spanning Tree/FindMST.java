
import java.util.Arrays;

public class FindMST {

    int numberOfVertices; //Number of vertices
    int numberOfEdges; //number of edges
    private int[] vertices; // Vertices array
    private Edge[] MST; // Minimum Spanning Tree Array
    private int mstCost; // Minimum Spanning Tree Cost

    /**
     * Constructor
     *
     * @param edges
     */
    public FindMST(Edge[] edges) {
        //Write codes here
        MST = new Edge[0]; //This line will deleted
    }

    /**
     * A utility function to find set of an element i (uses path compression technique)
     *
     * @param subsets
     * @param v
     * @return
     */
    private int find(Subset subsets[], int v) {
        //Write codes here
        return 0; //This line will deleted
    }


    /**
     * A function that does union of two sets of x and y (uses union by rank)
     *
     * @param subsets
     * @param x
     * @param y
     */
    private void Union(Subset subsets[], int x, int y) {
        //Write codes here
    }

    /**
     * Define all vertices from Edge array and return Vertex array
     *
     * @param edges
     * @return
     */
    private int[] CreateVertices(Edge[] edges) {
        //Write codes here
        return new int[1]; //This line will deleted
    }

    /**
     * Main calculate Minimum Spanning Tree method
     *
     * @param edges
     */
    public void calculateMST(Edge[] edges) {
        //Write codes here
    }

    /**
     * Get calculated Minimum Spanning Tree ArrayList
     *
     * @return
     */
    public Edge[] getMST() {
        return MST;
    }

    /**
     * Check vertex is included given arr[] or not
     * @param arr
     * @param vertex
     * @return
     */
    private boolean isVertexIncluded(int[] arr, int vertex) {
        //Write codes here
        return true; //This line will deleted
    }

    /**
     * Get cost of Minimum Spanning Tree
     *
     * @return
     */
    public int getMstCost() {
        return mstCost;
    }

    /**
     * Print Minimum Spanning Tree info
     */
    public void printMST() {
        //Write codes here
    }
}
